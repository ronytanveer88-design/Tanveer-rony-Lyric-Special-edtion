package com.lyricstudio.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_WRITE_STORAGE = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> filePickerLauncher;

    private final Map<String, PendingSave> activeSaves = new HashMap<>();
    private byte[] pendingLegacyBytes;
    private String pendingLegacyName;
    private String pendingLegacyMime;

    private static class PendingSave {
        final String fileName;
        final String mimeType;
        final ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        PendingSave(String fileName, String mimeType) {
            this.fileName = fileName;
            this.mimeType = mimeType;
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF090B12);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);

        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) return;
                    Uri[] results = null;
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        if (data.getClipData() != null) {
                            int count = data.getClipData().getItemCount();
                            results = new Uri[count];
                            for (int i = 0; i < count; i++) {
                                results[i] = data.getClipData().getItemAt(i).getUri();
                            }
                        } else if (data.getData() != null) {
                            results = new Uri[]{data.getData()};
                        }
                    }
                    filePathCallback.onReceiveValue(results);
                    filePathCallback = null;
                }
        );

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                List<String> mimeList = new ArrayList<>();
                if (params != null && params.getAcceptTypes() != null) {
                    for (String raw : params.getAcceptTypes()) {
                        if (raw == null) continue;
                        for (String part : raw.split(",")) {
                            String trimmed = part.trim();
                            if (trimmed.isEmpty()) continue;
                            if (trimmed.equalsIgnoreCase(".json")) {
                                mimeList.add("application/json");
                            } else if (trimmed.contains("/")) {
                                mimeList.add(trimmed);
                            }
                        }
                    }
                }

                if (mimeList.size() == 1) {
                    intent.setType(mimeList.get(0));
                } else {
                    intent.setType("*/*");
                    if (mimeList.size() > 1) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeList.toArray(new String[0]));
                    }
                }

                try {
                    filePickerLauncher.launch(Intent.createChooser(intent, "Select File"));
                    return true;
                } catch (Exception e) {
                    if (filePathCallback != null) {
                        filePathCallback.onReceiveValue(null);
                        filePathCallback = null;
                    }
                    Toast.makeText(MainActivity.this, "File picker unavailable", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript(
                        "(function(){return window.onAndroidBack?Boolean(window.onAndroidBack()):false;})()",
                        value -> {
                            if ("true".equals(value)) {
                                return;
                            }
                            if (webView.canGoBack()) {
                                webView.goBack();
                            } else {
                                setEnabled(false);
                                getOnBackPressedDispatcher().onBackPressed();
                            }
                        }
                );
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public synchronized String startFileSave(String fileName, String mimeType) {
            String safeName = (fileName == null || fileName.trim().isEmpty())
                    ? "lyric-studio-file"
                    : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
            String safeMime = (mimeType == null || mimeType.trim().isEmpty())
                    ? "application/octet-stream"
                    : mimeType;
            String id = UUID.randomUUID().toString();
            activeSaves.put(id, new PendingSave(safeName, safeMime));
            return id;
        }

        @JavascriptInterface
        public synchronized void appendFileChunk(String id, String base64Chunk) {
            PendingSave save = activeSaves.get(id);
            if (save == null || base64Chunk == null || base64Chunk.isEmpty()) return;
            byte[] decoded = Base64.decode(base64Chunk, Base64.DEFAULT);
            save.buffer.write(decoded, 0, decoded.length);
        }

        @JavascriptInterface
        public synchronized void finishFileSave(String id) {
            PendingSave save = activeSaves.remove(id);
            if (save == null) return;
            byte[] bytes = save.buffer.toByteArray();
            runOnUiThread(() -> writeFileToDownloads(bytes, save.fileName, save.mimeType));
        }
    }

    private void writeFileToDownloads(byte[] bytes, String fileName, String mimeType) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LyricStudio");

                ContentResolver resolver = getContentResolver();
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Could not create MediaStore entry");
                try (OutputStream os = resolver.openOutputStream(uri)) {
                    if (os == null) throw new IllegalStateException("Could not open output stream");
                    os.write(bytes);
                }
                Toast.makeText(this, "Saved: Downloads/LyricStudio/" + fileName, Toast.LENGTH_LONG).show();
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    pendingLegacyBytes = bytes;
                    pendingLegacyName = fileName;
                    pendingLegacyMime = mimeType;
                    ActivityCompat.requestPermissions(
                            this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            REQ_WRITE_STORAGE
                    );
                    return;
                }
                saveLegacyFile(bytes, fileName, mimeType);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void saveLegacyFile(byte[] bytes, String fileName, String mimeType) throws Exception {
        File dir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "LyricStudio"
        );
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("Could not create LyricStudio folder");
        }
        File outFile = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            fos.write(bytes);
        }
        MediaScannerConnection.scanFile(this, new String[]{outFile.getAbsolutePath()}, new String[]{mimeType}, null);
        Toast.makeText(this, "Saved: Downloads/LyricStudio/" + fileName, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_WRITE_STORAGE && pendingLegacyBytes != null) {
            byte[] b = pendingLegacyBytes;
            String n = pendingLegacyName;
            String m = pendingLegacyMime;
            pendingLegacyBytes = null;
            pendingLegacyName = null;
            pendingLegacyMime = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                try {
                    saveLegacyFile(b, n, m);
                } catch (Exception e) {
                    Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Storage permission required to save file", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
}
