# লিরিক স্টুডিও (Lyric Studio) — GitHub to Android APK

কোনো কোডিং ছাড়াই এই প্রজেক্ট থেকে আপনার Android ফোনের জন্য **APK** তৈরি করুন।

## ধাপ ১: ZIP আনজিপ করুন
- `lyric-studio-github-apk.zip` ফাইলটি আনজিপ (Extract) করুন।
- ভেতরে `.github`, `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, `README.md` ফাইলগুলো দেখবেন।

## ধাপ ২: GitHub-এ নতুন Repository তৈরি ও আপলোড করুন
1. [github.com/new](https://github.com/new) ওপেন করে যেকোনো নাম (যেমন `lyric-studio-apk`) দিয়ে **Create repository** চাপুন।
2. পরের পেজে **uploading an existing file** লিংকে ক্লিক করুন।
3. আনজিপ করা **ভেতরের সব ফাইল ও ফোল্ডার** (`.github` সহ) সরাসরি ড্র্যাগ করে আপলোড করুন।
   - ⚠️ খেয়াল রাখবেন: `.github` ফোল্ডারটি যেন সরাসরি repository-র মূল (root) ফোল্ডারে থাকে, কোনো বাড়তি ফোল্ডারের ভেতরে নয়।
4. নিচে **Commit changes** বাটনে ক্লিক করুন।

## ধাপ ৩: APK ডাউনলোড করুন
1. GitHub repository-তে উপরে **Actions** ট্যাবে যান।
2. **Build Android APK** workflow চলতে দেখবেন (১-২ মিনিট লাগবে)।
3. সবুজ টিক ✅ এলে ওই run-এ ক্লিক করুন।
4. একদম নিচে **Artifacts** সেকশন থেকে **LyricStudio-APK** ডাউনলোড করুন।
5. ডাউনলোড করা ZIP খুললেই আপনার `app-debug.apk` ফাইল পাবেন — ফোনে ইনস্টল করে ব্যবহার করুন!

---

## English Quick Steps
1. Extract this ZIP archive.
2. Create a new GitHub repository and upload **all extracted files and folders** (`.github`, `app`, `build.gradle`, `settings.gradle`, `gradle.properties`) directly to the repository root.
3. Open the **Actions** tab on GitHub — the **Build Android APK** workflow starts automatically (or click **Run workflow**).
4. Once finished (~2 minutes), download **LyricStudio-APK** from the **Artifacts** section and install `app-debug.apk` on your Android phone.
