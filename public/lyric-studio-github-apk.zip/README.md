# Tanvir's Creative Studio (All-in-One 4-in-1 Android APK)

এই প্রজেক্টে আপনার **৪টি অ্যাপ একসাথে** একটি সিঙ্গেল Android APK হিসেবে যুক্ত করা আছে:
1. 🎬 **১ · সিনেমা AI** (`CinemaMaster AI Director`)
2. 🎞️ **২ · ইন্ট্রো/আউট্রো** (`Intro / Outro Maker` — ফোনে সরাসরি ভিডিও ডাউনলোড সাপোর্টসহ)
3. 🌐 **৩ · ট্রান্সলেটর** (`লিরিক ট্রান্সলেটর` — এক ক্লিকে লিরিক ভিডিও স্টুডিওতে পাঠানোর বাটনসহ)
4. 🎵 **৪ · লিরিক ভিডিও স্টুডিও** (সম্পূর্ণ আপগ্রেডেড ভার্সন: Start/End Trim, Project Manager JSON, Letter Spacing, Bouncing Animation, Background Speed/Blur/Fade/Overlay Color & Opacity, Video Filter, Text Shadow & Offset, Text Glow, Text Outline, Text Gradient, Transition Speed, MP4/WebM, LRC, Thumbnail JPG)

---

## কোনো কোডিং ছাড়াই GitHub থেকে APK বানানোর সহজ নিয়ম (৫ মিনিট)

### ধাপ ১: ZIP ফাইল আনজিপ (Extract) করুন
আপনার ফোন বা কম্পিউটারে এই `.zip` ফাইলটি Extract করুন। ভেতরে `.github`, `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, `README.md` ফোল্ডার ও ফাইলগুলো পাবেন।

### ধাপ ২: GitHub-এ নতুন Repository তৈরি করুন
1. [github.com](https://github.com)-এ লগইন করুন।
2. উপরের `+` বাটন চাপুন → **New repository** সিলেক্ট করুন।
3. নাম দিন: `tanvir-creative-studio` (Public বা Private যেকোনোটি হতে পারে)।
4. **Create repository** চাপুন।

### ধাপ ৩: সব ফাইল আপলোড করুন
1. নতুন পেজে **uploading an existing file** লিংকে ক্লিক করুন।
2. আনজিপ করা **সব ফোল্ডার ও ফাইল** (বিশেষ করে `.github` ফোল্ডার এবং `app` ফোল্ডারসহ সবকিছু) একসাথে Drag & Drop করুন।
   > ⚠️ **গুরুত্বপূর্ণ:** `.github/workflows/build-apk.yml` ফাইলটি যেন অবশ্যই আপলোড হয়। (ফোনে/পিসিতে হিডেন ফাইল না দেখালে ফাইল ম্যানেজারে "Show hidden files" চালু করুন।)
3. নিচে **Commit changes** বাটন চাপুন।

### ধাপ ৪: GitHub Actions থেকে APK ডাউনলোড করুন
1. আপনার Repository-এর উপরের **Actions** ট্যাবে ক্লিক করুন।
2. **Build Tanvir Creative Studio APK** চালু হতে দেখবেন (হলুদ ঘুরন্ত আইকন → ২–৩ মিনিটে সবুজ ✅ টিক চিহ্ন হবে)।
3. সবুজ ✅ হওয়া Build-এ ক্লিক করুন।
4. নিচে **Artifacts** সেকশনে `TanvirCreativeStudio-APK` লেখা পাবেন — ওটায় ক্লিক করে ডাউনলোড করুন।
5. ডাউনলোড হওয়া ZIP খুলে ভেতরের `app-debug.apk` ফোনে ইনস্টল করুন!

### ধাপ ৫: ভিডিও ও ফাইল কোথায় সেভ হবে?
অ্যাপ থেকে বানানো সব ভিডিও (Intro/Outro, Lyric Video MP4/WebM), Thumbnail JPG, LRC এবং Project JSON সরাসরি আপনার ফোনের **`Downloads/TanvirCreativeStudio/`** ফোল্ডারে সেভ হবে।
